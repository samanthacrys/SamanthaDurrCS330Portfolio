#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/perpendicular.hpp>

int main()
{
	int Error(0);

	return Error;
}
