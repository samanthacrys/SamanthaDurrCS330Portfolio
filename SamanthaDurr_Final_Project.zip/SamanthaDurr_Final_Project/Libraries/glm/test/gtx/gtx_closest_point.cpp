#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/closest_point.hpp>

int main()
{
	int Error(0);

	return Error;
}
